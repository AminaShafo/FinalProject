Log
=====

R1:
- Added basic test JSON request and parsing

R2:
- Added functionality to Log.w FCB games from current date (basic fixture)

R3:
- Added basic fixture functionality (prints to screen)

R4:
- Added scroller

R5:
- Added material design assets (cards and toolbar)
- Renamed project directory to "MaterialTest"

R6:
- Changed addGame functionality: now stores details in an ArrayList of Game instances (as opposed to a huge string)

R7:
- Added Champions League games

R8:
- Implemented RecyclerView with Cards
- Added an indeterminate progress icon for loading

R9:
- Added bold text for dates and separated date/details into different TextViews

R10:
- Added drawer template and placeholder icon/color scheme

R11:
- Adjusted CSS for drawer and added icons
- Added Bundesliga selections (user can choose any Bundesliga team)

R12:
- Added La Liga and Premier League selections