FootballModelClass Tracker
======

An Android app that displays the upcoming fixtures of any team from three popular soccer leagues (Bundesliga, Barclay's Premier League and La Liga) and any upcoming Champions League games, as well as highlights in the form of gfycat links.

Requirements
-----
- Android 4.3 Jelly Bean (API 18)
- Android Studio v1.+
- Gradle

Building
-----
To build, import the `FootballTracker` directory into Android Studio.
