package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter  extends  RecyclerView.Adapter<Adapter.MyViewHolder> {

    LayoutInflater inflater;
    List<FootballModelClass> Football;

    public Adapter(Context ctx, List<FootballModelClass> FootballModelClass){
        this.inflater = LayoutInflater.from(ctx);
        this.Football = FootballModelClass;
    }

    @NonNull
    @Override
    public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = inflater.inflate(R.layout.custom_list_layout, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
//Bind data
        holder.Title.setText(Football.get(position).getTitle());
        holder.soccer.setText(Football.get(position).getThumbnail() );
//        picasso.get().load(Football.get(position).getDate()).into(holder.coverImage);
    }

    @Override
    public int getItemCount() {
        return Football.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView Title,soccer;
        ImageView coverImage;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            Title= itemView.findViewById(R.id.Title);
            soccer = itemView.findViewById(R.id.soccer);
            coverImage = itemView.findViewById(R.id.coverImage);
        }
    }
}
