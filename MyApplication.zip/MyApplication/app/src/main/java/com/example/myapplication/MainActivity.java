package com.example.myapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

//    private static final String JSON_URL = "https://www.scorebat.com/video-api/v1/";
    List<FootballModelClass> FootballModelClass;
    RecyclerView recyclerView;
    private static String Highlights_URL = "https://www.scorebat.com/video-api/v1/";
    Adapter adapter;
    private Object JsonArrayRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.footballList);
        FootballModelClass = new ArrayList<>();

        extractFootball();


    }

    private void extractFootball() {
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, Highlights_URL, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject FootballObject = response.getJSONObject(i);

                        FootballModelClass football = new FootballModelClass();
                        football.setTitle(FootballObject.getString("title").toString());
                        football.setEmbed(FootballObject.getString("embed").toString());
                        football.setUrl(FootballObject.getString("url").toString());
                        football.setThumbnail(FootballObject.getString("Thumbnail").toString());
                        football.setDate(FootballObject.getString("date").toString());
                        football.setSide1(FootballObject.getString("side1").toString());
                        football.setSide2(FootballObject.getString("side2").toString());
                        football.setCompetition(FootballObject.getString("competition").toString());
                        football.setVideos(FootballObject.getString("videos").toString());

                        FootballModelClass.add(football);


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                adapter = new Adapter(getApplicationContext(), FootballModelClass);
                recyclerView.setAdapter(adapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        queue.add(jsonArrayRequest);
    }
}