package com.example.myapplication;


public class FootballModelClass {

    private String title;
    private String embed;
    private String url;
    private String thumbnail;
    private String date;
    private String side1;
    private String side2;
    private String competition;
    private String videos;

    public FootballModelClass(){}

    public FootballModelClass(String title, String embed, String url, String thumbnail, String date, String side1, String side2, String competition, String videos) {
        this.title = title;
        this.embed = embed;
        this.url = url;
        this.thumbnail = thumbnail;
        this.date = date;
        this.side1 = side1;
        this.side2 = side2;
        this.competition = competition;
        this.videos = videos;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getEmbed() {
        return embed;
    }

    public void setEmbed(String embed) {
        this.embed = embed;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSide1() {
        return side1;
    }

    public void setSide1(String side1) {
        this.side1 = side1;
    }

    public String getSide2() {
        return side2;
    }

    public void setSide2(String side2) {
        this.side2 = side2;
    }

    public String getCompetition() {
        return competition;
    }

    public void setCompetition(String competition) {
        this.competition = competition;
    }

    public String getVideos() {
        return videos;
    }

    public void setVideos(String videos) {
        this.videos = videos;
    }
}
