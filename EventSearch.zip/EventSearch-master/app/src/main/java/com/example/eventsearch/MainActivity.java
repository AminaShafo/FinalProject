package com.example.eventsearch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * @author Najma Abdullahi
 * @version 2.1
 */

public class MainActivity extends AppCompatActivity {

    EditText searchEt, radiusEt;
    Button searchBtn;
    SharedPreferences sharedPreferences;
    RecyclerView recyclerView;

    String event, radius;
    ArrayList<Event> eventsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEt = findViewById(R.id.searchEt);
        radiusEt = findViewById(R.id.radiusEt);
        searchBtn = findViewById(R.id.searchBtn);
        recyclerView = findViewById(R.id.recyclerView);
        sharedPreferences = getSharedPreferences("app", Context.MODE_PRIVATE);

        //if the event and radius is already stored in the shared preference, get the values
        event = sharedPreferences.getString("event", null);
        radius = sharedPreferences.getString("radius", null);
        if (event != null) {
            //if the event is stored, populate it in the edit text
            searchEt.setText(event);
        }
        if (radius != null) {
            //if the radius is stored, populate it in the edit text
            radiusEt.setText(radius);
        }

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                event = searchEt.getText().toString();
                radius = radiusEt.getText().toString();
                if (event.isEmpty()) {
                    // if the event edit text is empty, show toast
                    Toast.makeText(MainActivity.this, "Input is empty", Toast.LENGTH_SHORT).show();
                } else if (radius.isEmpty()) {
                    // if the radius edit text is empty, show snack bar
                    Snackbar.make(MainActivity.this, view, "Radius is empty", Snackbar.LENGTH_LONG).show();
                } else {
                    //storing the event and radius in the shared preference
                    sharedPreferences.edit().putString("event", event).apply();
                    sharedPreferences.edit().putString("radius", radius).apply();
                    //calling the event search API
                    searchEvent();
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_saved:
                //open saved events activity
                startActivity(new Intent(this, SavedEventsActivity.class));
                return true;
            case R.id.menu_help:
                //show instructions in an alert dialog
                showInstructions();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void searchEvent() {
        String url = "https://app.ticketmaster.com/discovery/v2/events?apikey=7zLFiJszpnyE0aLVlFrUTTZurPlTdlaW&city=" + event + "&radius=" + radius + "&unit=km&locale=*&size=20";
        url = url.replace(" ", "%20");
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            Log.d("Event response : ", response);
            eventsList = new ArrayList<>();
            try {
                JSONObject jsonObject = new JSONObject(response);
                JSONObject pageObject = jsonObject.getJSONObject("page");
                int totalRecords = pageObject.getInt("totalElements");
                int totalPages = pageObject.getInt("totalPages");

                JSONObject embeddedObject = jsonObject.getJSONObject("_embedded");
                JSONArray eventsArray = embeddedObject.getJSONArray("events");

                for (int i = 0; i < eventsArray.length(); i++) {
                    String id = eventsArray.getJSONObject(i).getString("id");
                    String name = eventsArray.getJSONObject(i).getString("name");
                    String tmUrl = eventsArray.getJSONObject(i).getString("url");
                    String image = eventsArray.getJSONObject(i).getJSONArray("images").getJSONObject(0).getString("url");
                    String startingDate = eventsArray.getJSONObject(i).getJSONObject("dates").getJSONObject("start").getString("localDate");
                    if (eventsArray.getJSONObject(i).optJSONArray("priceRanges") != null) {
                        int minPrice = eventsArray.getJSONObject(i).optJSONArray("priceRanges").optJSONObject(0).optInt("min");
                        int maxPrice = eventsArray.getJSONObject(i).optJSONArray("priceRanges").optJSONObject(0).optInt("max");
                        String currency = eventsArray.getJSONObject(i).optJSONArray("priceRanges").optJSONObject(0).optString("currency");
                        eventsList.add(new Event(name, tmUrl, image, startingDate, minPrice, maxPrice, currency, id));
                    }
                }

                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                recyclerView.setHasFixedSize(true);
                EventsAdapter eventsAdapter = new EventsAdapter(this, eventsList);
                recyclerView.setAdapter(eventsAdapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }, error -> {
            if (error != null && error.getMessage() != null)
                Log.e("Error : ", error.getMessage());
        });

        LoadImages.getInstance(this).addToRequestQueue(stringRequest, "Event request");
    }

    private void showInstructions() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(R.string.instruction))
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                    }
                });

        AlertDialog d = builder.create();
        d.setTitle("Instructions");
        d.show();
    }
}