package com.example.eventsearch;

import java.io.Serializable;

public class Event implements Serializable {
    int id;
    String name;
    String url;
    String image;
    String startingDate;
    int minPrice;
    int maxPrice;
    String currency;
    String uniqId;

    /**
     * @param name         - name of the event
     * @param url          - ticket master url
     * @param image        - url of the image
     * @param startingDate - starting date of the event
     * @param minPrice     - min ticket price of the event
     * @param maxPrice     - max ticket price of the event
     * @param currency     - currency of the ticket
     * @param uniqId       - ticket master unique id of the event
     */
    public Event(String name, String url, String image, String startingDate, int minPrice, int maxPrice, String currency, String uniqId) {
        this.name = name;
        this.url = url;
        this.image = image;
        this.startingDate = startingDate;
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
        this.currency = currency;
        this.uniqId = uniqId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getStartingDate() {
        return startingDate;
    }

    public void setStartingDate(String startingDate) {
        this.startingDate = startingDate;
    }

    public int getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(int minPrice) {
        this.minPrice = minPrice;
    }

    public int getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(int maxPrice) {
        this.maxPrice = maxPrice;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getUniqId() {
        return uniqId;
    }

    public void setUniqId(String uniqId) {
        this.uniqId = uniqId;
    }
}
