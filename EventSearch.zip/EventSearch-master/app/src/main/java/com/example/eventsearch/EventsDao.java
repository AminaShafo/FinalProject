package com.example.eventsearch;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class EventsDao extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "ticketmaster.db";
    public static final String EVENTS_TABLE_NAME = "events";
    public static final String EVENTS_ID = "id";
    public static final String EVENTS_NAME = "name";
    public static final String EVENTS_URL = "url";
    public static final String EVENTS_IMAGE = "image";
    public static final String EVENTS_START_DATE = "start_date";
    public static final String EVENTS_MIN_PRICE = "min_price";
    public static final String EVENTS_MAX_PRICE = "max_price";
    public static final String EVENTS_CURRENCY = "currency";
    public static final String EVENTS_UNIQ_ID = "uniq_id";

    public EventsDao(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    /**
     * @param sqLiteDatabase
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(
                "create table " + EVENTS_TABLE_NAME +
                        "(id integer primary key, name text,url text,image text,start_date text,min_price int,max_price int,currency text,uniq_id text)"
        );
    }


    /**
     * @param sqLiteDatabase
     * @param i
     * @param i1
     */
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + EVENTS_TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    /**
     * @param event - event model object where all the date about the event is stored
     * @return - success or failed
     */
    public boolean insertEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EVENTS_NAME, event.getName());
        contentValues.put(EVENTS_URL, event.getUrl());
        contentValues.put(EVENTS_IMAGE, event.getImage());
        contentValues.put(EVENTS_START_DATE, event.getStartingDate());
        contentValues.put(EVENTS_MIN_PRICE, event.getMinPrice());
        contentValues.put(EVENTS_MAX_PRICE, event.getMaxPrice());
        contentValues.put(EVENTS_CURRENCY, event.getCurrency());
        contentValues.put(EVENTS_UNIQ_ID, event.getUniqId());
        db.insert(EVENTS_TABLE_NAME, null, contentValues);
        return true;
    }

    /**
     * @param uid - id of the event to get
     * @return - the event object
     */
    public Cursor getAnEvent(String uid) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("select * from " + EVENTS_TABLE_NAME + " where uniq_id='" + uid + "'", null);
    }

    /**
     * To get the number of rows in the event table
     *
     * @return - the number of rows in the event table
     */
    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        return (int) DatabaseUtils.queryNumEntries(db, EVENTS_TABLE_NAME);
    }

    /**
     * Delete an event
     *
     * @param id - id of the event to be deleted
     * @return
     */
    public Integer deleteEvent(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(EVENTS_TABLE_NAME, "id = ? ", new String[]{Integer.toString(id)});
    }

    /**
     * get all the events stored in the database
     *
     * @return - list of event object
     */
    public ArrayList<Event> getAllEvents() {
        ArrayList<Event> array_list = new ArrayList<>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + EVENTS_TABLE_NAME, null);
        res.moveToFirst();

        while (!res.isAfterLast()) {
            Event event = new Event(
                    res.getString(res.getColumnIndexOrThrow(EVENTS_NAME)),
                    res.getString(res.getColumnIndexOrThrow(EVENTS_URL)),
                    res.getString(res.getColumnIndexOrThrow(EVENTS_IMAGE)),
                    res.getString(res.getColumnIndexOrThrow(EVENTS_START_DATE)),
                    res.getInt(res.getColumnIndexOrThrow(EVENTS_MIN_PRICE)),
                    res.getInt(res.getColumnIndexOrThrow(EVENTS_MAX_PRICE)),
                    res.getString(res.getColumnIndexOrThrow(EVENTS_CURRENCY)),
                    res.getString(res.getColumnIndexOrThrow(EVENTS_UNIQ_ID))
            );
            event.setId(res.getColumnIndex(EVENTS_ID));
            array_list.add(event);
            res.moveToNext();
        }
        return array_list;
    }

}
