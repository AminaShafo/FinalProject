package com.example.eventsearch;

import androidx.appcompat.app.AppCompatActivity;

import android.app.FragmentTransaction;
import android.os.Bundle;
import android.widget.FrameLayout;

public class EventActivity extends AppCompatActivity {

    FrameLayout frameLayout;

    /**
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        //frame layout where the fragment is going to be replaced
        frameLayout = findViewById(R.id.eventFrame);

        //if the intent is not null, get the event data and send it to the fragment using constructor
        if (getIntent() != null) {
            Event event = (Event) getIntent().getSerializableExtra("event");
            EventFragment eventFragment = new EventFragment(event);
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.eventFrame, eventFragment, "eventFragment")
                    .disallowAddToBackStack()
                    .commit();
        } else {
            /// no event data is passed so, close this activity
            finish();
        }

    }
}