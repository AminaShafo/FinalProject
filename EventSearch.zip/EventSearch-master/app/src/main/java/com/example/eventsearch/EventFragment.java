package com.example.eventsearch;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.Picasso;

public class EventFragment extends Fragment {


    TextView nameTv, dateTv, priceTv, linkTv;
    ImageView eventIv;
    Button saveBtn;
    private EventsDao eventsDao;
    Event event;
    boolean eventAlreadyExists = false;
    int eventId = 0;

    /**
     * @param event - event object from the activity - to be populated in this fragment
     */
    public EventFragment(Event event) {
        // Required empty public constructor
        this.event = event;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_events, container, false);

        nameTv = view.findViewById(R.id.eventName);
        dateTv = view.findViewById(R.id.eventStartDate);
        priceTv = view.findViewById(R.id.eventPrice);
        linkTv = view.findViewById(R.id.eventLink);
        eventIv = view.findViewById(R.id.eventImage);
        saveBtn = view.findViewById(R.id.eventSave);

        //to access the database operations
        eventsDao = new EventsDao(requireContext());

        //populating the event data from the event object received in the constructor
        nameTv.setText(event.getName());
        dateTv.setText(event.getStartingDate());
        priceTv.setText(event.getMinPrice() + " " + event.getCurrency() + " - " + event.getMaxPrice() + " " + event.getCurrency());
        linkTv.setText(event.getUrl());

        //if the ticket master link is clicked, open the link in a browser
        linkTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (event.getUrl().isEmpty()) {
                    //the link is invalid
                    Toast.makeText(requireContext(), "Invalid link", Toast.LENGTH_SHORT).show();
                } else {
                    //open the link in a browser
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(event.getUrl()));
                    startActivity(browserIntent);
                }
            }
        });


        refresh();

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eventAlreadyExists) {
                    if (eventId != 0) {
                        showConfirmation();
                    } else {
                        Snackbar.make(view, "Unable to remove the Event from favourites", Snackbar.LENGTH_LONG).show();
                    }
                } else {
                    //add the event to the db
                    if (eventsDao.insertEvent(event)) {
                        eventAlreadyExists = true;
                        refresh();
                        Toast.makeText(requireContext(), "Event saved to favourites", Toast.LENGTH_SHORT).show();
                    } else {
                        Snackbar.make(view, "Unable to save the Event to favourites", Snackbar.LENGTH_LONG).show();
                    }
                }
            }
        });

        if (event.getImage() != null && !event.getImage().isEmpty())
            Picasso.get().load(event.getImage()).into(eventIv);

        return view;
    }

    /**
     * To check if the event is stored in the database or not
     */
    private void refresh() {
        Cursor rs = eventsDao.getAnEvent(event.getUniqId());

        if (rs.moveToFirst()) {
            int i = rs.getColumnIndex(EventsDao.EVENTS_UNIQ_ID);
            if (eventsDao.numberOfRows() > 0 && i > 0 && !rs.getString(i).isEmpty()) {
                eventId = rs.getInt(rs.getColumnIndexOrThrow(EventsDao.EVENTS_ID));
                eventAlreadyExists = true;
                saveBtn.setText("REMOVE EVENT FROM FAVOURITES");
            } else {
                eventAlreadyExists = false;
                saveBtn.setText("SAVE EVENT TO FAVOURITES");
            }
        } else {
            eventAlreadyExists = false;
            saveBtn.setText("SAVE EVENT TO FAVOURITES");;
        }

        if (!rs.isClosed()) rs.isClosed();
    }

    /**
     * Alert dialog to confirm if the user wants to remove the event from the database/saved events
     */
    private void showConfirmation() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setMessage("Are you sure to remove the event?")
                .setPositiveButton("Yes, Remove", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //deleting event from the database
                        eventsDao.deleteEvent(eventId);
                        eventId = 0;
                        eventAlreadyExists = false;
                        refresh();
                        Toast.makeText(requireContext(), "Event removed from favourites", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User cancelled the dialog
                        dialog.dismiss();
                    }
                });

        AlertDialog d = builder.create();
        d.setTitle("Confirmation");
        d.show();
    }
}