package com.example.eventsearch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class SavedEventsActivity extends AppCompatActivity {

    ArrayList<Event> eventsList;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_events);

        recyclerView = findViewById(R.id.savedEventsRv);


    }

    @Override
    protected void onResume() {
        super.onResume();
        EventsDao eventsDao = new EventsDao(this);
        //getting all the stored events in the database
        eventsList = eventsDao.getAllEvents();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        EventsAdapter eventsAdapter = new EventsAdapter(this, eventsList);
        recyclerView.setAdapter(eventsAdapter);

        if (eventsList.size() == 0) {
            //if there are no events found in the database, show the toast
            Toast.makeText(this, "No saved events found.", Toast.LENGTH_SHORT).show();
        }
    }
}