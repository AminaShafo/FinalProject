package algonquin.cst2335.shaf0052.Activites.Data;

import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;
// Databse class
import algonquin.cst2335.shaf0052.Activites.Model.Movie;

public interface MovieDao {
    //insert title method
    @Insert
    public long insertTitle(Movie m);
//getTitle method
    @Query("SELECT * FROM  Movie")
    public List<Movie> getTitle();
//deleteMessage class
    @Delete
    public void deleteMessage(Movie m);

}

