package algonquin.cst2335.shaf0052.Activites.uti;
public class Constants {
    public static final String URL_LEFT = "http://www.omdbapi.com/?apikey=3c59f6ef&s=";
    public static final String URL = "http://www.omdbapi.com/?apikey=3c59f6ef&i=";
}