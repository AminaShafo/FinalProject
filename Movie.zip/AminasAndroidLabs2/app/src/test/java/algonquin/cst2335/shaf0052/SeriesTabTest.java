package algonquin.cst2335.shaf0052;

import junit.framework.TestCase;

public class SeriesTabTest extends TestCase {

}